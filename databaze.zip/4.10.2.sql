CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    author VARCHAR(50),
    genre VARCHAR(50),
    price DECIMAL(10,2),
    published_year INT,
    pages INT
);
INSERT INTO books (title, author, genre, price, published_year, pages) VALUES
('Python Basics', 'Ali Karimov', 'Programming', 120000, 2020, 350),
('Advanced SQL', 'Ali Karimov', 'Programming', 150000, 2021, 420),
('Clean Code', 'Robert Martin', 'Programming', 200000, 2018, 500),
('Atomic Habits', 'James Clear', 'Psychology', 110000, 2019, 320),
('Deep Work', 'Cal Newport', 'Psychology', 130000, 2017, 290);
SELECT author, COUNT(*) AS book_count
FROM books
GROUP BY author;
SELECT genre, COUNT(*) AS book_count
FROM books
GROUP BY genre;
SELECT author, AVG(price) AS avg_price
FROM books
GROUP BY author;
SELECT genre, MAX(price) AS max_price
FROM books
GROUP BY genre;
SELECT published_year, COUNT(*) AS book_count
FROM books
GROUP BY published_year;
SELECT author, SUM(pages) AS total_pages
FROM books
GROUP BY author;
SELECT genre, AVG(pages) AS avg_pages
FROM books
GROUP BY genre;
